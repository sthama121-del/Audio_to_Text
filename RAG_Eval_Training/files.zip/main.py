# =============================================================================
# main.py — Master Orchestrator: End-to-End RAG Pipeline + Evaluation
# =============================================================================
#
# RUN THIS FILE:
#   python main.py
#
# WHAT IT DOES (in order):
#   1. Validates configuration & API keys
#   2. Ingests hr_policy.txt → chunks → ChromaDB vector store
#   3. For each evaluation question:
#        a) Retrieves relevant chunks (with scores for debugging)
#        b) Generates an answer using Claude
#   4. Runs the RAGAS evaluation suite (Faithfulness, Relevance, Precision, Recall)
#   5. Prints a rich terminal report with all scores and Q&A pairs
#
# INTERVIEW GOTCHA: "How is this pipeline structured for maintainability?"
# Answer: Each phase is a separate module with a single responsibility.
# You can swap ChromaDB for FAISS by editing ingestion.py only.
# You can swap Claude for GPT-4 by editing generation.py only.
# You can swap RAGAS for DeepEval by editing evaluation.py only.
# The orchestrator (this file) doesn't care about those internals.
# =============================================================================

import os
import sys
from typing import List

# --- Project modules ---
import config
from ingestion import run_ingestion
from retrieval import retrieve_chunks, retrieve_chunks_with_scores, format_context
from generation import generate_answer
from evaluation import prepare_eval_dataset, run_ragas_evaluation, score_per_sample
import report


# ---------------------------------------------------------------------------
# 1. Phase 2: Retrieve + Generate (for all eval questions)
# ---------------------------------------------------------------------------
def run_retrieve_and_generate(vector_store, eval_questions: List[dict]):
    """
    Loops through all evaluation questions, retrieves context, and generates answers.

    Returns structured data needed for evaluation.
    """
    print("\n" + "=" * 60)
    print(" PHASE 2: RETRIEVAL + GENERATION")
    print("=" * 60)

    questions = []
    answers = []
    contexts = []       # List[List[str]] — each item is a list of chunk texts
    ground_truths = []

    for i, item in enumerate(eval_questions, 1):
        question = item["question"]
        ground_truth = item["ground_truth"]

        print(f"\n[pipeline] Processing question {i}/{len(eval_questions)}...")
        print(f"[pipeline] Q: {question[:80]}...")

        # --- Retrieval with scores (for debugging transparency) ---
        scored_chunks = retrieve_chunks_with_scores(vector_store, question)

        # Log the scores so you can inspect retrieval quality
        print("[pipeline] Retrieval scores:")
        for j, (doc, score) in enumerate(scored_chunks, 1):
            preview = doc.page_content[:60].replace("\n", " ")
            print(f"[pipeline]   Chunk {j}: score={score:.4f} | \"{preview}...\"")

        # Extract just the Document objects for context formatting
        retrieved_docs = [doc for doc, _ in scored_chunks]

        # Format context for the LLM prompt
        context_text = format_context(retrieved_docs)

        # --- Generation ---
        answer = generate_answer(question, context_text)

        # --- Collect data for evaluation ---
        questions.append(question)
        answers.append(answer)
        # RAGAS expects contexts as a list of raw chunk text strings
        contexts.append([doc.page_content for doc in retrieved_docs])
        ground_truths.append(ground_truth)

    return questions, answers, contexts, ground_truths


# ---------------------------------------------------------------------------
# 2. Phase 3: Evaluation
# ---------------------------------------------------------------------------
def run_evaluation(questions, answers, contexts, ground_truths):
    """
    Runs the RAGAS evaluation and returns both aggregate and per-sample scores.
    """
    print("\n" + "=" * 60)
    print(" PHASE 3: RAGAS EVALUATION")
    print("=" * 60)

    # Prepare the dataset in RAGAS format
    eval_dataset = prepare_eval_dataset(questions, answers, contexts, ground_truths)

    # Run aggregate evaluation
    aggregate_scores = run_ragas_evaluation(eval_dataset)

    # Run per-sample evaluation for granular debugging
    print("\n[evaluation] Running per-sample breakdown...")
    per_sample = score_per_sample(eval_dataset)

    return aggregate_scores, per_sample


# ---------------------------------------------------------------------------
# 3. Main Entry Point
# ---------------------------------------------------------------------------
def main():
    """
    Master orchestration function. Runs the full pipeline end-to-end.
    """
    # ─── Validate environment ───
    config.validate_config()

    # ─── Resolve the path to hr_policy.txt ───
    # It lives in the same directory as this script
    script_dir = os.path.dirname(os.path.abspath(__file__))
    hr_policy_path = os.path.join(script_dir, "hr_policy.txt")

    # ─── PHASE 1: Ingestion ───
    vector_store = run_ingestion(hr_policy_path)

    # ─── PHASE 2: Retrieve + Generate ───
    questions, answers, contexts, ground_truths = run_retrieve_and_generate(
        vector_store,
        config.EVAL_QUESTIONS,
    )

    # ─── Print Q&A pairs for manual inspection BEFORE scoring ───
    report.print_qa_pairs(questions, answers, contexts)

    # ─── PHASE 3: Evaluation ───
    aggregate_scores, per_sample_scores = run_evaluation(
        questions, answers, contexts, ground_truths
    )

    # ─── PHASE 4: Report ───
    print("\n" + "=" * 60)
    print(" PHASE 4: EVALUATION REPORT")
    print("=" * 60)

    report.print_aggregate_report(aggregate_scores)
    report.print_per_question_report(per_sample_scores)
    report.print_interview_prep_summary()

    print("\n[pipeline] ✓ Pipeline complete. All phases executed successfully.")


# ---------------------------------------------------------------------------
# Entry point guard
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    main()
